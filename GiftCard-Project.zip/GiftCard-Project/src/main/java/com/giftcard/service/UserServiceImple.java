package com.giftcard.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.giftcard.dao.UserDao;
import com.giftcard.pojo.GiftCardOrderDetails;
import com.giftcard.pojo.Sender;


@Service
@Transactional
public class UserServiceImple implements UserService{
	
	@Autowired
	private UserDao userDao;

	
	@Override
	public List<Sender> getAllSenders() {
		// TODO Auto-generated method stub
		return userDao.getAllSenders();
	}

	@Override
	public int inserUser(Sender sender) {
		// TODO Auto-generated method stub
		return userDao.insertUser(sender);
		
	}

	@Override
	public int  placeNewOrder(GiftCardOrderDetails giftCardOrderDetails) {
		// TODO Auto-generated method stub
		return userDao.placeNewOrder(giftCardOrderDetails);
		
	}

	@Override
	public List<GiftCardOrderDetails> getAllOrders() {
		// TODO Auto-generated method stub
		return userDao.getAllOrders();
	}

	@Override
	public List<GiftCardOrderDetails> getAllOrdersByName(String senderName) {
		// TODO Auto-generated method stub
		return userDao.getAllOrdersByName(senderName);
	}

}
