package com.giftcard.service;

import java.util.List;

import com.giftcard.pojo.GiftCardOrderDetails;
import com.giftcard.pojo.Sender;

public interface UserService {
	
	public List<Sender> getAllSenders();
	public int inserUser(Sender sender);
	public int placeNewOrder(GiftCardOrderDetails giftCardOrderDetails);
	public List<GiftCardOrderDetails> getAllOrders();
	public List<GiftCardOrderDetails> getAllOrdersByName(String senderName);
	
	

}
