package com.giftcard.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "GiftCardOrderDetails")
public class GiftCardOrderDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "gift_orderId")
	private int gift_orderId;

	
	@Column(name = "sender_name")
	private String sender_name;
	
	@Column(name = "gift_amount")
	private Long gift_amount;
	
	
	@Column(name = "gift_reciver_name")
	private String gift_reciver_name;
	
	@Column(name = "gift_reciver_email")
	private String gift_reciver_email;

	
	@Column(name = "gift_reciver_phone")
	private String gift_reciver_phone;
	
	
	@Column(name="gift_reciver_address")
	private String gift_reciver_address;


	public int getGift_orderId() {
		return gift_orderId;
	}


	public void setGift_orderId(int gift_orderId) {
		this.gift_orderId = gift_orderId;
	}


	public String getSender_name() {
		return sender_name;
	}


	public void setSender_name(String sender_name) {
		this.sender_name = sender_name;
	}


	public Long getGift_amount() {
		return gift_amount;
	}


	public void setGift_amount(Long gift_amount) {
		this.gift_amount = gift_amount;
	}


	public String getGift_reciver_name() {
		return gift_reciver_name;
	}


	public void setGift_reciver_name(String gift_reciver_name) {
		this.gift_reciver_name = gift_reciver_name;
	}


	public String getGift_reciver_email() {
		return gift_reciver_email;
	}


	public void setGift_reciver_email(String gift_reciver_email) {
		this.gift_reciver_email = gift_reciver_email;
	}


	public String getGift_reciver_phone() {
		return gift_reciver_phone;
	}


	public void setGift_reciver_phone(String gift_reciver_phone) {
		this.gift_reciver_phone = gift_reciver_phone;
	}


	public String getGift_reciver_address() {
		return gift_reciver_address;
	}


	public void setGift_reciver_address(String gift_reciver_address) {
		this.gift_reciver_address = gift_reciver_address;
	}
	
	
  
	

}
