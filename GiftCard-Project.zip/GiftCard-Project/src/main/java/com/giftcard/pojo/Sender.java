package com.giftcard.pojo;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="giftsenderusers")
public class Sender {
	
	
	
@Column(name="user_name")
@Id	
private String user_name;

@Column(name="user_password")
private String user_password;

@Column(name="sender_name")
private String sender_name;

@Column(name="sender_email")
private String sender_email;

@Column(name="sender_phone")
private String sender_phone;

public String getUser_name() {
	return user_name;
}

public void setUser_name(String user_name) {
	this.user_name = user_name;
}

public String getUser_password() {
	return user_password;
}

public void setUser_password(String user_password) {
	this.user_password = user_password;
}

public String getSender_name() {
	return sender_name;
}

public void setSender_name(String sender_name) {
	this.sender_name = sender_name;
}

public String getSender_email() {
	return sender_email;
}

public void setSender_email(String sender_email) {
	this.sender_email = sender_email;
}

public String getSender_phone() {
	return sender_phone;
}

public void setSender_phone(String sender_phone) {
	this.sender_phone = sender_phone;
}





}
