package com.giftcard.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.giftcard.pojo.GiftCardOrderDetails;
import com.giftcard.pojo.Sender;
import com.giftcard.model.HibernateConnection;

@Repository
public class UserDaoImpl implements UserDao {
	
	@Autowired
    private SessionFactory sessionFactory= HibernateConnection.doHibernateConnection();;

	@Override
	public List<Sender> getAllSenders() {
		
		 return sessionFactory.getCurrentSession().createQuery("from Sender").getResultList();
	}

	@Override
	public int  insertUser(Sender sender) {
		return (int) sessionFactory.getCurrentSession().save(sender);
		
	}
	@Override
	public int placeNewOrder(GiftCardOrderDetails giftCardOrderDetails) {
		// TODO Auto-generated method stub
		return (int) sessionFactory.getCurrentSession().save(giftCardOrderDetails);
		
	}

	@Override
	public List<GiftCardOrderDetails> getAllOrders() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("from GiftCardOrderDetails").getResultList();
	}

	@Override
	public List<GiftCardOrderDetails> getAllOrdersByName(String senderName) {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("from GiftCardOrderDetails").getResultList();
	}

}
