package com.giftcard.dao;


import java.util.List;

import com.giftcard.pojo.GiftCardOrderDetails;
import com.giftcard.pojo.Sender;



public interface UserDao {
	public List<Sender> getAllSenders();
	public int insertUser(Sender sender);
	public int placeNewOrder(GiftCardOrderDetails giftCardOrderDetails);
	public List<GiftCardOrderDetails> getAllOrders();
	public List<GiftCardOrderDetails> getAllOrdersByName(String senderName);
}
