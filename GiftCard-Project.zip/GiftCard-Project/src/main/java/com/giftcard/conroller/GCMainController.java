package com.giftcard.conroller;


import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.giftcard.pojo.GiftCardOrderDetails;
import com.giftcard.pojo.Sender;
//import com.giftcard.pojo.Sender;
//import com.giftcard.pojo.GiftCardOrderDetails;
import com.giftcard.service.UserService;

@Controller
public class GCMainController {
	
	@Autowired
	private UserService userService;
	
	
	// Initial request mapped and redirected to login page
	@RequestMapping(value="/")
	public ModelAndView showHomePage(HttpServletResponse response) throws IOException{
		return new ModelAndView("login");
		
	}
	
	// This method will validate the password
	
	@RequestMapping(value="/validateUser")
	public ModelAndView validateUser(HttpServletRequest request, @RequestParam String username, @RequestParam String password) throws IOException{
		String userType=null;
		if("admin".equals(username) && "admin".equals(password) ){
			userType="admin";
	 }
		else
		{
		List<Sender> sender = userService.getAllSenders();
		for(Sender b:sender) {
			if(b.getUser_name().equals(username) && b.getUser_password().equals(password) ){
				userType="user";
				
				break;
			}
		}
		}
		if(userType!=null) {
			return new ModelAndView(userType);
		}
		else
			return new ModelAndView("home");
	}
	
	//
	
	
	// It will redirect to jsp page to accept user registration data
		@RequestMapping(value="/addNewUser")
		public ModelAndView addNewUser() throws IOException{
			return new ModelAndView("signup");
		}
		
		
		
		// Inserting the new user
		@RequestMapping(value="/insertUser")
		public ModelAndView insertUser(@RequestParam String username, @RequestParam String password,@RequestParam String sendername, @RequestParam String senderemail,@RequestParam String senderphone) throws IOException{
			Sender sender = new Sender();
			sender.setUser_name(username);
			sender.setUser_password(password);
			sender.setSender_email(sendername);
			sender.setSender_email(senderemail);
			sender.setSender_email(senderphone);
			userService.inserUser(sender);			
			return new ModelAndView("login");
		}	
	
		// Order Transaction Starts Here.
		
		@RequestMapping(value="/newOrder")
		public ModelAndView newOrder() throws IOException{
			return new ModelAndView("newgiftorder");
		}
		
		
		@RequestMapping(value="/placenewOrder")
		public ModelAndView placenewOrder(@RequestParam String giftsendername, @RequestParam long giftamount, @RequestParam String giftreceivername,
		@RequestParam String giftreceiveremail, @RequestParam String giftreceiverphone, @RequestParam String giftreceiveraddress)throws IOException{
		//public ModelAndView placenewOrder()
			
			GiftCardOrderDetails giftCardOrderDetails = new GiftCardOrderDetails();
			giftCardOrderDetails.setSender_name(giftsendername);
			giftCardOrderDetails.setGift_amount(giftamount);
			giftCardOrderDetails.setGift_reciver_name(giftreceivername);
			giftCardOrderDetails.setGift_reciver_email(giftreceiveremail);
			giftCardOrderDetails.setGift_reciver_phone(giftreceiverphone);
			giftCardOrderDetails.setGift_reciver_address(giftreceiveraddress);
			userService.placeNewOrder(giftCardOrderDetails);	
			return new ModelAndView("orderconfirm");
		}
		
		
		@RequestMapping(value="/logout")
		public ModelAndView logout(HttpServletResponse response) throws IOException{
			return new ModelAndView("home");
		}
		
	   // Order Management and Report
		
		
		@RequestMapping(value="/allorderhistory")
		public ModelAndView adminorderhistory() throws IOException{
			List<GiftCardOrderDetails> allorders = userService.getAllOrders();
			System.out.println(allorders);
			return new ModelAndView("orderHistory","orders",allorders);
		}
	

}
