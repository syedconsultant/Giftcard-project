package com.DBTestCases;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class DBConnectionTest {



    Connection conn;
	Statement statement;
	
	String url = "jdbc:mysql://localhost:3306/";
	String db_name = "giftcard";
	String username = "root";
	String password = "test";


    @Before
	public void setUp() throws Exception {
	
	   try
		{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url+db_name , username , password);
			statement = conn.createStatement();
					}
		catch(Exception e)
		{
			System.out.print("Error");
		}
	   
    }
		
		
		
		@Test
	public void dbConnection() throws Exception {
	
	
		String username="admin";
		String password="admin";
	  
	   ResultSet rs = statement.executeQuery("select count(*) from user where username='"+username+"' and password='"+password+"'");
			int count = 0;
			
			boolean status;
			
		 while(rs.next())
			{
				count = rs.getInt(1);
			}
			
			rs.close();	
			
			
		 if(count == 1)
			{
				status=true;
			}
			else
			{
				status=false;
			}
			
	     assertTrue(status);
		
	}
		
    }