package com.DBTestCases;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.giftcard.pojo.GiftCardOrderDetails;
import com.giftcard.pojo.Sender;




public class HibernateConnectionTest {


public static SessionFactory sessionFactory;
    


    @Before
	    public void setUp() throws Exception {
	
	
	   Properties database = new Properties();
		database.setProperty("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
		database.setProperty("hibernate.connection.username", "root");
		database.setProperty("hibernate.connection.password", "test");
		database.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/test");
		database.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		
		Configuration cfg = new Configuration()
							.setProperties(database)
							.addPackage("com.demo.pojo")
							.addAnnotatedClass(Sender.class)
							.addAnnotatedClass(GiftCardOrderDetails.class);
		
		StandardServiceRegistryBuilder ssrb = new StandardServiceRegistryBuilder().applySettings(cfg.getProperties());
		
		sessionFactory = cfg.buildSessionFactory(ssrb.build());
	
	
	   
	   
    }
		
		
		
	@Test
	public void HibernatedbConnection() throws Exception {
	
	       String username="admin";
		   String password="admin";
		   boolean status;
	try{
			//SessionFactory sessionFactory = HibernateConnection.doHibernateConnection();
			Session session = sessionFactory.openSession();
			
			session.beginTransaction();
			
			List<Sender> sender = session.createQuery("From User where username='"+username+"' and password='"+password+"'").list();
			
			session.close();
			
			if(sender.size() == 1)
				
				status=true;
			else
				
				 status=false;
		}
		catch(Exception e){
			System.out.println( "Please try again...");
		}
	
	
		
		
	}
		
    }
