package com.GCServiceTestCases;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.giftcard.dao.UserDao;
import com.giftcard.pojo.GiftCardOrderDetails;
import com.giftcard.pojo.Sender;

//import com.cognizant.truyum.dao.CartEmptyException;
//import com.cognizant.truyum.model.MenuItem;

import com.giftcard.service.UserServiceImple;


public class GCServiceTest {
	
	private UserServiceImple userservice;


    @Test
	public void testGetAllSenders() throws Exception {

		List<Sender> senderList = userservice.getAllSenders();
		System.out.println("Sender List :" + senderList);
		
		assertTrue(senderList.size()>0);

	}
	
	@Test
	public void testGetAllOrders() throws Exception {

		List<GiftCardOrderDetails> allOrder = userservice.getAllOrders();
		System.out.println("Cift Card All Order List :" + allOrder);
		
		assertTrue(allOrder.size()>0);

	}
	
	
	
	

}